#!/bin/sh
#
# $Header$
#

mv $1 $1.tmp
sed "
	s/ECMWF/UNI-C/g
	s/www.ecmwf.int/www.uni-c.dk/g
	s/Shinfield Park/DTU, Building 304/g
	s/Reading, Berks./DK-2800 Kgs. Lyngby/g
	s/RG2 9AX  England/Denmark/

	" < $1.tmp > $1

diff $1 $1.tmp

mv $1.tmp /tmp
