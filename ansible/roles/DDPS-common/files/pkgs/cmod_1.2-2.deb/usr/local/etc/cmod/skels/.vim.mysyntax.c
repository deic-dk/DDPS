
"
" my additional syntax highlightings for C
"

syn region cComment matchgroup=cPreCondit start="^#if[ \t]*0" end="^#endif" end="^#else" keepend 

